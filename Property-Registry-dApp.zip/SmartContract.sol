// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @title Property Registry & Transfer Management (Student Prototype)
/// @notice Demonstrates how real estate registration, ownership transfer fees and
///         municipal notices could be recorded transparently on a blockchain.
///         It is NOT connected to CDA, RDA, LDA, Punjab Land Records Authority (PLRA),
///         e-Stamp, Raast, JazzCash, Easypaisa or any real land registry database.
/// @dev Payments use Sepolia test ETH only. Amounts are demo values, not real PKR.
contract PropertyRegistry {

    // ---------------------------------------------------------------
    // Data structures
    // ---------------------------------------------------------------
    struct Property {
        address propertyOwner;    // wallet that currently owns the property
        uint8 propertyType;       // 0 = Residential Plot, 1 = House, 2 = Commercial
        uint256 registeredAt;     // block timestamp
        uint256 transfersDone;    // number of ownership transfers
        uint256 totalFeesWei;     // total transfer fees paid (wei)
        uint256 unpaidNotices;    // number of unpaid notices
    }

    struct TransferRecord {
        string propertyId;
        address from;
        address to;
        uint8 zone;               // 0 = Islamabad, 1 = Rawalpindi, 2 = Lahore
        uint256 amount;           // wei paid
        uint256 timestamp;
    }

    struct Notice {
        string propertyId;
        uint8 noticeType;         // 0 = Unpaid property tax, 1 = Illegal construction, 2 = Encroachment
        uint256 fine;             // wei
        uint256 issuedAt;
        bool paid;
        uint256 paidAt;
    }

    // ---------------------------------------------------------------
    // State variables
    // ---------------------------------------------------------------
    /// @notice Deployer. Acts as the "Registrar" (issues notices) and
    ///         the treasury that receives all transfer fees and fines.
    address public registrar;

    // Demo prices in wei (Sepolia test ETH). Set in the constructor.
    uint256[3] public zoneBaseFee;        // per zone
    uint256[3] public typeMultiplier;     // per property type
    uint256[3] public noticeFine;         // per notice type

    /// @notice A property with this many unpaid notices cannot be transferred
    ///         until they are cleared (automated "no-dues" business rule).
    uint256 public constant MAX_UNPAID_NOTICES = 3;

    uint256 public transferCount;
    uint256 public noticeCount;

    mapping(string => Property) private properties;
    mapping(uint256 => TransferRecord) public transferRecords;   // ids start at 1
    mapping(uint256 => Notice) public notices;                   // ids start at 1

    // ---------------------------------------------------------------
    // Events (permanent, searchable logs)
    // ---------------------------------------------------------------
    event PropertyRegistered(string propertyId, address indexed propertyOwner, uint8 propertyType);
    event PropertyTransferred(uint256 indexed transferId, string propertyId, address indexed from, address indexed to, uint8 zone, uint256 amount);
    event NoticeIssued(uint256 indexed noticeId, string propertyId, uint8 noticeType, uint256 fine);
    event NoticePaid(uint256 indexed noticeId, string propertyId, address indexed payer, uint256 amount);

    // ---------------------------------------------------------------
    // Constructor
    // ---------------------------------------------------------------
    constructor() {
        registrar = msg.sender;

        // Zone base transfer fees: Islamabad, Rawalpindi, Lahore
        zoneBaseFee[0] = 0.0010 ether;
        zoneBaseFee[1] = 0.0006 ether;
        zoneBaseFee[2] = 0.0008 ether;

        // Property type multipliers: Plot x1, House x2, Commercial x3
        typeMultiplier[0] = 1;
        typeMultiplier[1] = 2;
        typeMultiplier[2] = 3;

        // Fines: Unpaid property tax, Illegal construction, Encroachment
        noticeFine[0] = 0.0010 ether;
        noticeFine[1] = 0.0020 ether;
        noticeFine[2] = 0.0005 ether;
    }

    // ---------------------------------------------------------------
    // 1) WRITE: register a property (needs MetaMask approval, no ETH sent)
    // ---------------------------------------------------------------
    /// @param propertyId Unique property reference, e.g. "ISB-F7-101" (frontend upper-cases it)
    /// @param propertyType 0 = Residential Plot, 1 = House, 2 = Commercial
    function registerProperty(string memory propertyId, uint8 propertyType) public {
        require(bytes(propertyId).length >= 3 && bytes(propertyId).length <= 20, "Property ID must be 3-20 characters");
        require(propertyType < 3, "Invalid property type");
        require(properties[propertyId].propertyOwner == address(0), "Property already registered");

        properties[propertyId] = Property({
            propertyOwner: msg.sender,
            propertyType: propertyType,
            registeredAt: block.timestamp,
            transfersDone: 0,
            totalFeesWei: 0,
            unpaidNotices: 0
        });

        emit PropertyRegistered(propertyId, msg.sender, propertyType);
    }

    // ---------------------------------------------------------------
    // 2) WRITE + PAYABLE: transfer ownership (needs MetaMask approval + ETH fee)
    // ---------------------------------------------------------------
    /// @param propertyId Registered property reference
    /// @param newOwner Wallet that will become the new owner
    /// @param zone 0 = Islamabad, 1 = Rawalpindi, 2 = Lahore
    function transferProperty(string memory propertyId, address newOwner, uint8 zone) public payable {
        Property storage p = properties[propertyId];
        require(p.propertyOwner != address(0), "Property not registered");
        require(msg.sender == p.propertyOwner, "Only the current owner can transfer");
        require(newOwner != address(0) && newOwner != msg.sender, "Invalid new owner address");
        require(zone < 3, "Invalid zone");
        require(p.unpaidNotices < MAX_UNPAID_NOTICES, "Too many unpaid notices: clear them first");

        uint256 fee = zoneBaseFee[zone] * typeMultiplier[p.propertyType];
        require(msg.value == fee, "Incorrect transfer fee");

        // Update records first, then send funds (safe order)
        address previousOwner = msg.sender;
        p.propertyOwner = newOwner;
        p.transfersDone += 1;
        p.totalFeesWei += msg.value;

        transferCount += 1;
        transferRecords[transferCount] = TransferRecord(propertyId, previousOwner, newOwner, zone, msg.value, block.timestamp);

        emit PropertyTransferred(transferCount, propertyId, previousOwner, newOwner, zone, msg.value);

        (bool ok, ) = payable(registrar).call{value: msg.value}("");
        require(ok, "Transfer to treasury failed");
    }

    // ---------------------------------------------------------------
    // 3) WRITE (registrar only): issue a notice against a property
    // ---------------------------------------------------------------
    /// @param propertyId Registered property reference
    /// @param noticeType 0 = Unpaid property tax, 1 = Illegal construction, 2 = Encroachment
    function issueNotice(string memory propertyId, uint8 noticeType) public {
        require(msg.sender == registrar, "Only the registrar can issue notices");
        require(properties[propertyId].propertyOwner != address(0), "Property not registered");
        require(noticeType < 3, "Invalid notice type");

        noticeCount += 1;
        notices[noticeCount] = Notice({
            propertyId: propertyId,
            noticeType: noticeType,
            fine: noticeFine[noticeType],
            issuedAt: block.timestamp,
            paid: false,
            paidAt: 0
        });
        properties[propertyId].unpaidNotices += 1;

        emit NoticeIssued(noticeCount, propertyId, noticeType, noticeFine[noticeType]);
    }

    // ---------------------------------------------------------------
    // 4) WRITE + PAYABLE: pay a notice fine (needs MetaMask approval + ETH)
    // ---------------------------------------------------------------
    /// @param noticeId Notice number (starts at 1)
    function payNotice(uint256 noticeId) public payable {
        require(noticeId >= 1 && noticeId <= noticeCount, "Notice does not exist");

        Notice storage n = notices[noticeId];
        require(!n.paid, "Notice already paid");

        Property storage p = properties[n.propertyId];
        require(msg.sender == p.propertyOwner, "Only the property owner can pay this notice");
        require(msg.value == n.fine, "Incorrect fine amount");

        // Update records first, then send funds (prevents duplicate payment)
        n.paid = true;
        n.paidAt = block.timestamp;
        p.unpaidNotices -= 1;

        emit NoticePaid(noticeId, n.propertyId, msg.sender, msg.value);

        (bool ok, ) = payable(registrar).call{value: msg.value}("");
        require(ok, "Transfer to treasury failed");
    }

    // ---------------------------------------------------------------
    // 5) READ (view): get a property's record. Free, no MetaMask popup.
    // ---------------------------------------------------------------
    function getProperty(string memory propertyId)
        public
        view
        returns (
            address propertyOwner,
            uint8 propertyType,
            uint256 registeredAt,
            uint256 transfersDone,
            uint256 totalFeesWei,
            uint256 unpaidNotices
        )
    {
        Property memory p = properties[propertyId];
        require(p.propertyOwner != address(0), "Property not registered");
        return (p.propertyOwner, p.propertyType, p.registeredAt, p.transfersDone, p.totalFeesWei, p.unpaidNotices);
    }
}
